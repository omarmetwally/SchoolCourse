﻿using System;
namespace StudentTeacherApi.Dtos
{
    public class LoginDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class StudentDto
    {
        public int StudentId { get; set; }
        public string FullName { get; set; }
        public string City { get; set; }
        public bool Gender { get; set; }
        public string Email { get; set; }
        public int? ParentId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Image { get; set; }
        public string ForgetPasswordKey { get; set; }
        public int MajorId { get; set; }

    }
    public class UserFP
    {
        public string email { get; set; }
    }

    public class userFPP
    {
        public string email { get; set; }
        public string key { get; set; }
    }

    public class userCP
    {
        public string email { get; set; }
        public string key { get; set; }
        public string password { get; set; }
    }
}
