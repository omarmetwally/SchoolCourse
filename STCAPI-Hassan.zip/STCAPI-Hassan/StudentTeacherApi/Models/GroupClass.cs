﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class GroupClass
    {
        public GroupClass()
        {
            Assignment = new HashSet<Assignment>();
            Exam = new HashSet<Exam>();
            InvolveIn = new HashSet<InvolveIn>();
        }

        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public DateTime StartDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public int CourseId { get; set; }
        public int? StudentCapacity { get; set; }
        public int? CenterId { get; set; }
        public string RepeatedDay { get; set; }
        public int? Price { get; set; }
        public int? HomeClassId { get; set; }

        public Center Center { get; set; }
        public Course Course { get; set; }
        public HomeClass HomeClass { get; set; }
        public ICollection<Assignment> Assignment { get; set; }
        public ICollection<Exam> Exam { get; set; }
        public ICollection<InvolveIn> InvolveIn { get; set; }
    }
}
