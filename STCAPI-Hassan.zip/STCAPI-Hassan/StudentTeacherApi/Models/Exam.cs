﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Exam
    {
        public int ExamId { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public decimal Results { get; set; }
        public int GroupId { get; set; }
        public int MajorId { get; set; }

        public GroupClass Group { get; set; }
    }
}
