﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class StudentToken
    {
        public int StudentId { get; set; }
        public int TokenId { get; set; }

        public Student Student { get; set; }
        public Tokens Token { get; set; }
    }
}
