﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class HaveCourse
    {
        public int CenterId { get; set; }
        public int CourseId { get; set; }
        public int MajorId { get; set; }

        public Center Center { get; set; }
        public Course Course { get; set; }
    }
}
