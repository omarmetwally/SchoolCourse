﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class ParentEmail
    {
        public int Email { get; set; }
        public int ParentId { get; set; }

        public Parent Parent { get; set; }
    }
}
