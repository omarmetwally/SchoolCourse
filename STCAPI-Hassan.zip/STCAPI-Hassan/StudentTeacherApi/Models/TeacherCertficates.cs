﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class TeacherCertficates
    {
        public int Certficates { get; set; }
        public int TeacherId { get; set; }

        public Teacher Teacher { get; set; }
    }
}
