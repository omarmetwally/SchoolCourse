﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Student
    {
        public Student()
        {
            InvolveIn = new HashSet<InvolveIn>();
            StudentPhone = new HashSet<StudentPhone>();
            StudentToken = new HashSet<StudentToken>();
            Study = new HashSet<Study>();
        }

        public int StudentId { get; set; }
        public string FullName { get; set; }
        public string City { get; set; }
        public bool Gender { get; set; }
        public string Email { get; set; }
        public int? ParentId { get; set; }
        public byte[] Password { get; set; }
        public string Image { get; set; }
        public string ForgetPasswordKey { get; set; }
        public int MajorId { get; set; }
        public byte[] PasswordSalt { get; set; }

        public Major Major { get; set; }
        public Parent Parent { get; set; }
        public ICollection<InvolveIn> InvolveIn { get; set; }
        public ICollection<StudentPhone> StudentPhone { get; set; }
        public ICollection<StudentToken> StudentToken { get; set; }
        public ICollection<Study> Study { get; set; }
    }
}
