﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class TeacherPhone
    {
        public int Phone { get; set; }
        public int TeacherId { get; set; }

        public Teacher Teacher { get; set; }
    }
}
