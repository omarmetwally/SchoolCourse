﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class HomeClass
    {
        public HomeClass()
        {
            GroupClass = new HashSet<GroupClass>();
        }

        public string City { get; set; }
        public string Street { get; set; }
        public string Region { get; set; }
        public int HomeClassId { get; set; }
        public int Name { get; set; }
        public int TeacherId { get; set; }

        public Teacher Teacher { get; set; }
        public ICollection<GroupClass> GroupClass { get; set; }
    }
}
