﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Teach
    {
        public int TeacherId { get; set; }
        public int MajorId { get; set; }

        public Major Major { get; set; }
        public Teacher Teacher { get; set; }
    }
}
