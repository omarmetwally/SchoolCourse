﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class TeacherTokens
    {
        public int TeacherId { get; set; }
        public int TokenId { get; set; }

        public Teacher Teacher { get; set; }
        public Tokens Token { get; set; }
    }
}
