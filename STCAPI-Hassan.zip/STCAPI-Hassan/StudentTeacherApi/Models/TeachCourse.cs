﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class TeachCourse
    {
        public int TeacherId { get; set; }
        public int CourseId { get; set; }

        public Course Course { get; set; }
        public Teacher Teacher { get; set; }
    }
}
