﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Center
    {
        public Center()
        {
            GroupClass = new HashSet<GroupClass>();
            HaveCourse = new HashSet<HaveCourse>();
            Work = new HashSet<Work>();
        }

        public int CenterId { get; set; }
        public string CenterName { get; set; }
        public string City { get; set; }
        public string Street { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }

        public ICollection<GroupClass> GroupClass { get; set; }
        public ICollection<HaveCourse> HaveCourse { get; set; }
        public ICollection<Work> Work { get; set; }
    }
}
