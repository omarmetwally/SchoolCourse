﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Course
    {
        public Course()
        {
            GroupClass = new HashSet<GroupClass>();
            HaveCourse = new HashSet<HaveCourse>();
            Study = new HashSet<Study>();
            TeachCourse = new HashSet<TeachCourse>();
        }

        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public int MajorId { get; set; }

        public Major Major { get; set; }
        public ICollection<GroupClass> GroupClass { get; set; }
        public ICollection<HaveCourse> HaveCourse { get; set; }
        public ICollection<Study> Study { get; set; }
        public ICollection<TeachCourse> TeachCourse { get; set; }
    }
}
