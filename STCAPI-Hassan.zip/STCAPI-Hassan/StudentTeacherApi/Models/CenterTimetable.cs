﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class CenterTimetable
    {
        public int TimeTableId { get; set; }
        public int TeacherId { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public int CourseId { get; set; }

        public CenterTimetable TimeTable { get; set; }
        public CenterTimetable InverseTimeTable { get; set; }
    }
}
