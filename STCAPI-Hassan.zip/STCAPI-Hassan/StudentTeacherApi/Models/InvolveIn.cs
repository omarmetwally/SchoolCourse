﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class InvolveIn
    {
        public int StudentId { get; set; }
        public int GroupId { get; set; }

        public GroupClass Group { get; set; }
        public Student Student { get; set; }
    }
}
