﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Work
    {
        public int TeacherId { get; set; }
        public int CenterId { get; set; }

        public Center Center { get; set; }
        public Teacher Teacher { get; set; }
    }
}
