﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Rooms
    {
        public int RoomId { get; set; }
        public int NoChairs { get; set; }
        public int CenterId { get; set; }

        public Center Center { get; set; }
    }
}
