﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class StudentPhone
    {
        public int Phone { get; set; }
        public int StudentId { get; set; }

        public Student Student { get; set; }
    }
}
