﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Teacher
    {
        public Teacher()
        {
            HomeClass = new HashSet<HomeClass>();
            Teach = new HashSet<Teach>();
            TeachCourse = new HashSet<TeachCourse>();
            TeacherCertficates = new HashSet<TeacherCertficates>();
            TeacherPhone = new HashSet<TeacherPhone>();
            TeacherTokens = new HashSet<TeacherTokens>();
            Work = new HashSet<Work>();
        }

        public int TeacherId { get; set; }
        public string FullName { get; set; }
        public bool Gender { get; set; }
        public string City { get; set; }
        public decimal Rank { get; set; }
        public string Email { get; set; }
        public string Image { get; set; }
        public bool Activation { get; set; }
        public string ForgetPasswordKey { get; set; }
        public string Description { get; set; }
        public byte[] Password { get; set; }
        public byte[] PasswordSalt { get; set; }

        public ICollection<HomeClass> HomeClass { get; set; }
        public ICollection<Teach> Teach { get; set; }
        public ICollection<TeachCourse> TeachCourse { get; set; }
        public ICollection<TeacherCertficates> TeacherCertficates { get; set; }
        public ICollection<TeacherPhone> TeacherPhone { get; set; }
        public ICollection<TeacherTokens> TeacherTokens { get; set; }
        public ICollection<Work> Work { get; set; }
    }
}
