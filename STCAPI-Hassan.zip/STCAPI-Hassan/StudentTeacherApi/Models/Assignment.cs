﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Assignment
    {
        public int AssignmnetId { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public int GroupId { get; set; }
        public int MajorId { get; set; }

        public GroupClass Group { get; set; }
    }
}
