﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace StudentTeacherApi.Models
{
    public partial class DBContext : DbContext
    {
        public DBContext()
        {
        }

        public DBContext(DbContextOptions<DBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Assignment> Assignment { get; set; }
        public virtual DbSet<Center> Center { get; set; }
        public virtual DbSet<CenterTimetable> CenterTimetable { get; set; }
        public virtual DbSet<Course> Course { get; set; }
        public virtual DbSet<Exam> Exam { get; set; }
        public virtual DbSet<GroupClass> GroupClass { get; set; }
        public virtual DbSet<HaveCourse> HaveCourse { get; set; }
        public virtual DbSet<HomeClass> HomeClass { get; set; }
        public virtual DbSet<InvolveIn> InvolveIn { get; set; }
        public virtual DbSet<Major> Major { get; set; }
        public virtual DbSet<Parent> Parent { get; set; }
        public virtual DbSet<ParentEmail> ParentEmail { get; set; }
        public virtual DbSet<ParentPhone> ParentPhone { get; set; }
        public virtual DbSet<Student> Student { get; set; }
        public virtual DbSet<StudentPhone> StudentPhone { get; set; }
        public virtual DbSet<StudentToken> StudentToken { get; set; }
        public virtual DbSet<Study> Study { get; set; }
        public virtual DbSet<Teach> Teach { get; set; }
        public virtual DbSet<TeachCourse> TeachCourse { get; set; }
        public virtual DbSet<Teacher> Teacher { get; set; }
        public virtual DbSet<TeacherCertficates> TeacherCertficates { get; set; }
        public virtual DbSet<TeacherPhone> TeacherPhone { get; set; }
        public virtual DbSet<TeacherTokens> TeacherTokens { get; set; }
        public virtual DbSet<Tokens> Tokens { get; set; }
        public virtual DbSet<Work> Work { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=OmarMetwallyPC;Initial Catalog=App;Integrated Security=True");
//            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Assignment>(entity =>
            {
                entity.HasKey(e => new { e.AssignmnetId, e.GroupId, e.MajorId });

                entity.Property(e => e.AssignmnetId).HasColumnName("AssignmnetID");

                entity.Property(e => e.GroupId).HasColumnName("Group_ID");

                entity.Property(e => e.MajorId).HasColumnName("MajorID");

                entity.Property(e => e.Date).HasColumnType("date");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.Assignment)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Assignment__6754599E");
            });

            modelBuilder.Entity<Center>(entity =>
            {
                entity.Property(e => e.CenterId).HasColumnName("CenterID");

                entity.Property(e => e.CenterName)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Description).HasColumnName("description");

                entity.Property(e => e.Street)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<CenterTimetable>(entity =>
            {
                entity.HasKey(e => e.TimeTableId);

                entity.ToTable("Center_Timetable");

                entity.Property(e => e.TimeTableId)
                    .HasColumnName("TimeTableID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.EndTime).HasColumnName("End_Time");

                entity.Property(e => e.StartTime).HasColumnName("Start_Time");

                entity.Property(e => e.TeacherId).HasColumnName("TeacherID");

                entity.HasOne(d => d.TimeTable)
                    .WithOne(p => p.InverseTimeTable)
                    .HasForeignKey<CenterTimetable>(d => d.TimeTableId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Center_Timetable_Center_Timetable");
            });

            modelBuilder.Entity<Course>(entity =>
            {
                entity.HasKey(e => new { e.CourseId, e.MajorId });

                entity.HasIndex(e => e.CourseId)
                    .HasName("IX_Course")
                    .IsUnique();

                entity.Property(e => e.CourseId).HasColumnName("Course_ID");

                entity.Property(e => e.MajorId).HasColumnName("MajorID");

                entity.Property(e => e.CourseName)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.HasOne(d => d.Major)
                    .WithMany(p => p.Course)
                    .HasForeignKey(d => d.MajorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Course__MajorID__60A75C0F");
            });

            modelBuilder.Entity<Exam>(entity =>
            {
                entity.HasKey(e => new { e.ExamId, e.GroupId, e.MajorId });

                entity.Property(e => e.ExamId).HasColumnName("ExamID");

                entity.Property(e => e.GroupId).HasColumnName("Group_ID");

                entity.Property(e => e.MajorId).HasColumnName("MajorID");

                entity.Property(e => e.Date).HasColumnType("date");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Results).HasColumnType("decimal(18, 0)");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.Exam)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Exam__6A30C649");
            });

            modelBuilder.Entity<GroupClass>(entity =>
            {
                entity.HasKey(e => e.GroupId);

                entity.ToTable("Group_Class");

                entity.Property(e => e.GroupId)
                    .HasColumnName("GroupID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CenterId).HasColumnName("CenterID");

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.EndTime).HasColumnName("End_Time");

                entity.Property(e => e.GroupName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.HomeClassId).HasColumnName("HomeClassID");

                entity.Property(e => e.RepeatedDay)
                    .HasColumnName("Repeated_day")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.StartDate).HasColumnType("date");

                entity.Property(e => e.StartTime).HasColumnName("Start_Time");

                entity.Property(e => e.StudentCapacity).HasColumnName("Student_Capacity");

                entity.HasOne(d => d.Center)
                    .WithMany(p => p.GroupClass)
                    .HasForeignKey(d => d.CenterId)
                    .HasConstraintName("FK_Group_Class_Center");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.GroupClass)
                    .HasPrincipalKey(p => p.CourseId)
                    .HasForeignKey(d => d.CourseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Group_Class_Course");

                entity.HasOne(d => d.HomeClass)
                    .WithMany(p => p.GroupClass)
                    .HasForeignKey(d => d.HomeClassId)
                    .HasConstraintName("FK_Group_Class_HomeClass");
            });

            modelBuilder.Entity<HaveCourse>(entity =>
            {
                entity.HasKey(e => new { e.CenterId, e.CourseId, e.MajorId });

                entity.ToTable("Have_Course");

                entity.Property(e => e.CenterId).HasColumnName("CenterID");

                entity.Property(e => e.CourseId).HasColumnName("Course_ID");

                entity.Property(e => e.MajorId).HasColumnName("MajorID");

                entity.HasOne(d => d.Center)
                    .WithMany(p => p.HaveCourse)
                    .HasForeignKey(d => d.CenterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Have_Cour__Cente__6D0D32F4");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.HaveCourse)
                    .HasForeignKey(d => new { d.CourseId, d.MajorId })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Have_Course__6E01572D");
            });

            modelBuilder.Entity<HomeClass>(entity =>
            {
                entity.Property(e => e.HomeClassId)
                    .HasColumnName("HomeClassID")
                    .ValueGeneratedNever();

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Street)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.TeacherId).HasColumnName("TeacherID");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.HomeClass)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_HomeClass_Teacher");
            });

            modelBuilder.Entity<InvolveIn>(entity =>
            {
                entity.HasKey(e => new { e.StudentId, e.GroupId });

                entity.ToTable("Involve_In");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.InvolveIn)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Involve_I__Group__6166761E");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.InvolveIn)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Involve_I__Stude__607251E5");
            });

            modelBuilder.Entity<Major>(entity =>
            {
                entity.Property(e => e.MajorId)
                    .HasColumnName("MajorID")
                    .ValueGeneratedNever();

                entity.Property(e => e.MajorName)
                    .IsRequired()
                    .HasMaxLength(70);
            });

            modelBuilder.Entity<Parent>(entity =>
            {
                entity.Property(e => e.ParentId).HasColumnName("ParentID");

                entity.Property(e => e.Job)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<ParentEmail>(entity =>
            {
                entity.HasKey(e => new { e.Email, e.ParentId });

                entity.ToTable("Parent_Email");

                entity.Property(e => e.ParentId).HasColumnName("ParentID");

                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.ParentEmail)
                    .HasForeignKey(d => d.ParentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Parent_Em__Paren__5812160E");
            });

            modelBuilder.Entity<ParentPhone>(entity =>
            {
                entity.HasKey(e => new { e.Phone, e.ParentId });

                entity.ToTable("Parent_Phone");

                entity.Property(e => e.ParentId).HasColumnName("ParentID");

                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.ParentPhone)
                    .HasForeignKey(d => d.ParentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Parent_Ph__Paren__5AEE82B9");
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasIndex(e => e.Email)
                    .HasName("IX_Student")
                    .IsUnique();

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(e => e.ForgetPasswordKey)
                    .HasColumnName("forgetPasswordKey")
                    .HasMaxLength(10);

                entity.Property(e => e.FullName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.MajorId).HasColumnName("MajorID");

                entity.Property(e => e.ParentId).HasColumnName("ParentID");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password");

                entity.Property(e => e.PasswordSalt)
                    .IsRequired()
                    .HasColumnName("passwordSalt");

                entity.HasOne(d => d.Major)
                    .WithMany(p => p.Student)
                    .HasForeignKey(d => d.MajorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Student_Major");

                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.Student)
                    .HasForeignKey(d => d.ParentId)
                    .HasConstraintName("FK__Student__ParentI__5DCAEF64");
            });

            modelBuilder.Entity<StudentPhone>(entity =>
            {
                entity.HasKey(e => new { e.Phone, e.StudentId });

                entity.ToTable("Student_Phone");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.StudentPhone)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Student_P__Stude__70DDC3D8");
            });

            modelBuilder.Entity<StudentToken>(entity =>
            {
                entity.HasKey(e => new { e.StudentId, e.TokenId });

                entity.ToTable("Student_Token");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.TokenId).HasColumnName("TokenID");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.StudentToken)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Student_Token_Student");

                entity.HasOne(d => d.Token)
                    .WithMany(p => p.StudentToken)
                    .HasForeignKey(d => d.TokenId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Student_Token_Tokens");
            });

            modelBuilder.Entity<Study>(entity =>
            {
                entity.HasKey(e => new { e.StudentId, e.CourseId });

                entity.HasIndex(e => new { e.StudentId, e.CourseId })
                    .HasName("PK__Study__Course");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.CourseId).HasColumnName("Course_ID");

                entity.Property(e => e.Score).HasColumnType("decimal(18, 0)");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.Study)
                    .HasPrincipalKey(p => p.CourseId)
                    .HasForeignKey(d => d.CourseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Study_Course");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.Study)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Study_Student");
            });

            modelBuilder.Entity<Teach>(entity =>
            {
                entity.HasKey(e => new { e.TeacherId, e.MajorId });

                entity.Property(e => e.TeacherId).HasColumnName("TeacherID");

                entity.Property(e => e.MajorId).HasColumnName("MajorID");

                entity.HasOne(d => d.Major)
                    .WithMany(p => p.Teach)
                    .HasForeignKey(d => d.MajorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Teach__MajorID__47DBAE45");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.Teach)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Teach__TeacherID__46E78A0C");
            });

            modelBuilder.Entity<TeachCourse>(entity =>
            {
                entity.HasKey(e => new { e.TeacherId, e.CourseId });

                entity.ToTable("Teach_Course");

                entity.Property(e => e.TeacherId).HasColumnName("TeacherID");

                entity.Property(e => e.CourseId).HasColumnName("Course_ID");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.TeachCourse)
                    .HasPrincipalKey(p => p.CourseId)
                    .HasForeignKey(d => d.CourseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Teach_Course_Course");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.TeachCourse)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Teach_Course_Teacher");
            });

            modelBuilder.Entity<Teacher>(entity =>
            {
                entity.Property(e => e.TeacherId).HasColumnName("TeacherID");

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Description).HasColumnType("text");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(e => e.ForgetPasswordKey)
                    .HasColumnName("forgetPasswordKey")
                    .HasMaxLength(10);

                entity.Property(e => e.FullName)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(e => e.Password).IsRequired();

                entity.Property(e => e.PasswordSalt).IsRequired();

                entity.Property(e => e.Rank).HasColumnType("decimal(18, 0)");
            });

            modelBuilder.Entity<TeacherCertficates>(entity =>
            {
                entity.HasKey(e => new { e.Certficates, e.TeacherId });

                entity.ToTable("Teacher_Certficates");

                entity.Property(e => e.TeacherId).HasColumnName("TeacherID");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.TeacherCertficates)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Teacher_C__Teach__52593CB8");
            });

            modelBuilder.Entity<TeacherPhone>(entity =>
            {
                entity.HasKey(e => new { e.Phone, e.TeacherId });

                entity.ToTable("Teacher_Phone");

                entity.Property(e => e.TeacherId).HasColumnName("TeacherID");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.TeacherPhone)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Teacher_P__Teach__5535A963");
            });

            modelBuilder.Entity<TeacherTokens>(entity =>
            {
                entity.HasKey(e => new { e.TeacherId, e.TokenId });

                entity.ToTable("Teacher_Tokens");

                entity.Property(e => e.TeacherId).HasColumnName("TeacherID");

                entity.Property(e => e.TokenId).HasColumnName("TokenID");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.TeacherTokens)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Teacher_Tokens_Teacher");

                entity.HasOne(d => d.Token)
                    .WithMany(p => p.TeacherTokens)
                    .HasForeignKey(d => d.TokenId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Teacher_Tokens_Tokens");
            });

            modelBuilder.Entity<Tokens>(entity =>
            {
                entity.HasKey(e => e.TokenId);

                entity.Property(e => e.TokenId).HasColumnName("TokenID");

                entity.Property(e => e.Token)
                    .IsRequired()
                    .HasColumnType("text");
            });

            modelBuilder.Entity<Work>(entity =>
            {
                entity.HasKey(e => new { e.TeacherId, e.CenterId });

                entity.ToTable("work");

                entity.Property(e => e.TeacherId).HasColumnName("TeacherID");

                entity.Property(e => e.CenterId).HasColumnName("CenterID");

                entity.HasOne(d => d.Center)
                    .WithMany(p => p.Work)
                    .HasForeignKey(d => d.CenterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__work__CenterID__440B1D61");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.Work)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__work__TeacherID__4316F928");
            });
        }
    }
}
