﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Parent
    {
        public Parent()
        {
            ParentEmail = new HashSet<ParentEmail>();
            ParentPhone = new HashSet<ParentPhone>();
            Student = new HashSet<Student>();
        }

        public int ParentId { get; set; }
        public string Name { get; set; }
        public string Job { get; set; }

        public ICollection<ParentEmail> ParentEmail { get; set; }
        public ICollection<ParentPhone> ParentPhone { get; set; }
        public ICollection<Student> Student { get; set; }
    }
}
