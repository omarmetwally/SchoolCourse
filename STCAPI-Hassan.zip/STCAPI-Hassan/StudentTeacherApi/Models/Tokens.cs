﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Tokens
    {
        public Tokens()
        {
            StudentToken = new HashSet<StudentToken>();
            TeacherTokens = new HashSet<TeacherTokens>();
        }

        public int TokenId { get; set; }
        public string Token { get; set; }

        public ICollection<StudentToken> StudentToken { get; set; }
        public ICollection<TeacherTokens> TeacherTokens { get; set; }
    }
}
