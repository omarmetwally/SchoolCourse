﻿using System;
using System.Collections.Generic;

namespace StudentTeacherApi.Models
{
    public partial class Major
    {
        public Major()
        {
            Course = new HashSet<Course>();
            Student = new HashSet<Student>();
            Teach = new HashSet<Teach>();
        }

        public int MajorId { get; set; }
        public string MajorName { get; set; }

        public ICollection<Course> Course { get; set; }
        public ICollection<Student> Student { get; set; }
        public ICollection<Teach> Teach { get; set; }
    }
}
