﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentTeacherApi.Models;

namespace StudentTeacherApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeClassGroupController : Controller
    {

        DBContext context;
        public HomeClassGroupController(DBContext dB)
        {
            context = dB;
        }

        [HttpGet("TeacherHomeClass")]

        public async Task<IActionResult> GetTeacherHomeclass(int homeid, int techid)
        {
            var homeclass = context.HomeClass.Single(m => m.HomeClassId == homeid);
            if (homeclass == null && homeclass.TeacherId == null)
                return BadRequest();

            return Ok(context.HomeClass.Include(m => m.Teacher).Where(m => m.TeacherId == techid));
        }

    }
}