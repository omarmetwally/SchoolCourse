﻿using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using StudentTeacherApi.Dtos;
using StudentTeacherApi.Models;
using StudentTeacherApi.Services;

namespace StudentTeacherApi.Controllers
{
    [Authorize(Policy = "Student")]
    [ApiController]
    [Route("/[controller]")]
    public class StudentController : Controller
    {
        private readonly DBContext context;
        IHostingEnvironment env;
        IConfiguration configuration;
        IUserService userServices;
        public StudentController(DBContext _context, IHostingEnvironment _env, IConfiguration _configuration, IUserService user)
        {
            context = _context;
            env = _env;
            configuration = _configuration;
            userServices = user;
        }

        //Registration handler
        [AllowAnonymous]
        [HttpPost, Route("register")]
        public IActionResult registration([FromBody] StudentDto studentdto)
        {

            var email = context.Student.SingleOrDefault(x => x.Email == studentdto.Email);
            if (email != null) { return BadRequest("Email found"); }
           
            Student student = studentDtoToStudent(studentdto);

            context.Student.Add(student);
            context.SaveChanges();
            return Ok("saved");
        }

        //Login Handler
        [AllowAnonymous]
        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> login([FromBody] LoginDto loginDto)
        {
            var user = context.Student.SingleOrDefault(x => x.Email == loginDto.Email);
            if (user == null) return NotFound("email or password are wrong");
            var id = user.StudentId.ToString() ;
            string tk;
            if (userServices.VerifyPasswordHash(loginDto.Password, user.Password, user.PasswordSalt) == true)
            { 
                tk = userServices.authenticate(user.StudentId.ToString(), "Student");
                context.Tokens.Add(new Tokens { Token = tk });
                await context.SaveChangesAsync();

              /*  var cid = context.Tokens.SingleOrDefault(x => x.Token == tk).TokenId;
                context.StudentToken.Add(new StudentToken
                {
                    StudentId = user.StudentId,
                    TokenId = cid,
                });*/
                return Ok(tk);

            }
            return NotFound("wrong email or password");
        }


        //update student's info.
        [HttpPut]
        [Route("update")]
        public IActionResult update([FromHeader] string Authorization, [FromBody] StudentDto studentDto)
        {
            var id = userServices.getUID(Authorization);
            var user = context.Student.SingleOrDefault(x => x.StudentId == id);
           
            if (studentDto.Email != null && user.Email != studentDto.Email) {
                var email = context.Student.SingleOrDefault(x => x.Email == studentDto.Email);
                if (email != null) { return BadRequest("Email found"); }
                user.Email = studentDto.Email;
            }

            if (studentDto.FullName != null && user.FullName != studentDto.FullName) user.FullName = studentDto.FullName;
            if (studentDto.City != null && user.City != studentDto.City) user.City = studentDto.City;
            if (user.Gender != studentDto.Gender) user.Gender = studentDto.Gender;
           
            context.Student.Update(user);
            context.SaveChanges();
            return Ok("success");
        }


        //Delete user profile permanently 
        [HttpDelete]
        [Route("Delete")]
        public IActionResult Delete([FromHeader] string Authorization)
        {
            var id = userServices.getUID(Authorization);
            var user = context.Student.SingleOrDefault(x => x.StudentId == id);
            context.Student.Remove(user);
            context.SaveChanges();
            return Ok("deleted success");
        }


        //uploading Image section, use Form to test it using POSTMAN
        [Route("imageUploading")]
        [HttpPost]
        public async Task<IActionResult> imageUploadingAsync([FromHeader] string Authorization, IFormFile file)
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory()+ "/wwwroot/Images", file.FileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);

            }
            var id = userServices.getUID(Authorization);
            var userMatching = context.Student.SingleOrDefault(x => x.StudentId == id);
            userMatching.Image = filePath;
            context.SaveChangesAsync();
            return Ok(new { userMatching.StudentId, filePath });

        }

        //Download image section, use Form to test it using POSTMAN
        [HttpPost, Route("imageDownloading")]
        public async Task<IActionResult> imageDownloadingAsync([FromHeader] string Authorization)
        {

            var id = userServices.getUID(Authorization);
            var userMatching = context.Student.SingleOrDefault(x => x.StudentId == id);
            var image = System.IO.File.OpenRead(userMatching.Image);
            return File(image, "image/jpeg");
        }


        //if user forget his password, please to test the email enter your email and password if it didn't work
        [HttpPost]
        [Route("ForgetPassword")]
        public IActionResult forgetPassword([FromBody] UserFP userfp)
        {
            var user = context.Student.SingleOrDefault(x =>
             x.Email == userfp.email);
            if (user == null) return NotFound("there's no account with this email");
            string key = userServices.RandomString(8);
           // user.forgetPasswordKey = key;
            using (var message = new MailMessage())
            {

                message.To.Add(new MailAddress(user.Email, "To Email"));
                message.From = new MailAddress(configuration["Gmail_Email"], "From Email");
                message.Subject = "NO REPLY";
                message.Body = $"your key: {key}";
                message.IsBodyHtml = true;
                using (var client = new SmtpClient("smtp.gmail.com"))
                {
                    client.Port = 587;
                    client.Credentials = new NetworkCredential(configuration["Gmail_Email"], configuration["Gmail_Password"]);
                    client.EnableSsl = true;
                    client.Send(message);
                    context.SaveChanges();
                    return Ok("Check your email for key");
                }
            }
        }

        [HttpPost, Route("checkKeyCorrect")]
        public IActionResult checkKeyCorrect([FromBody] userFPP userfpp)
        {
            var user = context.Student.SingleOrDefault(x => x.Email == userfpp.email);
            if (user == null) return NotFound("user not found");
          //  if (user.forgetPasswordKey != userfpp.key) return BadRequest("key isn't correct!");
            return Ok();
        }

        [HttpPut, Route("ChangeForgottenPassword")]
        public IActionResult ChangeForgottenPassword([FromBody] userCP users)
        { 
            var user = context.Student.SingleOrDefault(x => x.Email == users.email);
            if (users.key != user.ForgetPasswordKey) return BadRequest("something went wrong");
            user.ForgetPasswordKey = null;
            byte[] psdhash, psdsalt;
            userServices.CreatePasswordHash(users.password, out psdhash, out psdsalt);
            user.Password = psdhash;
            user.PasswordSalt = psdsalt;

            context.SaveChanges();
            return Ok("password changed");
        }

        public Student studentDtoToStudent(StudentDto studentdto)
        {
            byte[] psdhash, psdsalt;
            userServices.CreatePasswordHash(studentdto.Password, out psdhash, out psdsalt);
            Student student = new Student
            {
                FullName = studentdto.FullName,
                City = studentdto.City,
                Gender = studentdto.Gender,
                Email = studentdto.Email,
                Password = psdhash,
                PasswordSalt = psdsalt,
                MajorId = studentdto.MajorId
            };
            return student;
        }
    }


}