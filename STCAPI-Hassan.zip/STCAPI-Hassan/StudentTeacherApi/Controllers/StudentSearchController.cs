﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StudentTeacherApi.Models;

namespace StudentTeacherApi.Controllers
{
    [ApiController]
   // [Authorize(Policy = "Student"), AutoValidateAntiforgeryToken]
    [Route("StudentSearch")]
    public class StudentSearchController : Controller
    {
        DBContext context;
        public StudentSearchController(DBContext dB)
        {
            context = dB;
        }

        //display all centers sorted by cities each 10
        [HttpGet("CenterSearch/{skipInt}")]
        public async Task<IActionResult> CenterSearch(int skipInt = 0)
        {
            return Ok(context.Center.OrderBy(x => x.City).Skip(10 * skipInt).Take(10).ToList());
        }

        [HttpGet("CenterSearchStudentCity/{skipInt}/{City}")]
        public async Task<IActionResult> CenterSearch(int skipInt = 0, string city = "")
        {
            return Ok(context.Center.Where(x => x.City == city).Skip(10 * skipInt).Take(10).ToList());
        }


        [HttpGet("CenterSearchName/{skipInt}/{name}")]
        public async Task<IActionResult> CenterSearchName(int skipInt = 0, string name = "")
        {
            return Ok(context.Center.Where(x => x.CenterName.Contains(name)).Skip(10 * skipInt).Take(10).ToList());
        }

        //display all Teacher sorted by user city each 10
        
        [HttpGet("TeacherSearchStudentCity/{skipInt}/{City}")]
        public async Task<IActionResult> TeacherSearch(int skipInt = 0, string city = "")
        {
            return Ok(context.Teacher.Where(x => x.City == city).Skip(10 * skipInt).Take(10).ToList());
        }


        [HttpGet("CenterSearchName/{skipInt}/{name}")]
        public async Task<IActionResult> TeacherSearchName(int skipInt = 0, string name = "")
        {
            return Ok(context.Teacher.Where(x => x.FullName.Contains(name)).Skip(10 * skipInt).Take(10).ToList());
        }

    }
}