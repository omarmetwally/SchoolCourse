# STCAPI
Student Teacher Center api
